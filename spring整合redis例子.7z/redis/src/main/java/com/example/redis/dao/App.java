package com.example.redis.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.example.redis.entity.User;

/**
 * Hello world!
 *
 */
public class App 
{
    @SuppressWarnings("resource")
	public static void main( String[] args )
    {
    	ApplicationContext ac =  new ClassPathXmlApplicationContext("classpath:/applicationContext.xml");
        UserDao userDAO = (UserDao)ac.getBean("userDao");
        User user = new User();
        user.setId(1);
        user.setName("liuxg");
        userDAO.saveUser(user);
        
        User liuxg = userDAO.getUser(1);
        System.out.println(liuxg.getName());
    	
    }
}
